import { RecommendationDashboard } from "@/components/RecommendationDashboard";
import { User } from "@/data/sampleData";

interface IndexProps {
  user: User | null;
  onSignOut: () => void;
}

const Index = ({ user, onSignOut }: IndexProps) => {
  return <RecommendationDashboard user={user} onSignOut={onSignOut} />;
};

export default Index;
