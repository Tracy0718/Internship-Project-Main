import { useState } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import { SignInPage } from "./components/SignInPage";
import { sampleUsers } from "./data/sampleData";

const queryClient = new QueryClient();

const App = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);

  const handleSignIn = (userId: string) => {
    setCurrentUserId(userId);
    setIsAuthenticated(true);
  };

  const handleSignOut = () => {
    setCurrentUserId(null);
    setIsAuthenticated(false);
  };

  const currentUser = currentUserId ? sampleUsers.find(u => u.id === currentUserId) : null;

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        {!isAuthenticated ? (
          <SignInPage onSignIn={handleSignIn} />
        ) : (
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<Index user={currentUser} onSignOut={handleSignOut} />} />
              {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        )}
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;
