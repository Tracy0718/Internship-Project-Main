// Sample data for the recommendation system demonstration
import macbookProImage from '@/assets/macbook-pro.jpg';
import psychologyBookImage from '@/assets/psychology-book.jpg';
import yogaMatImage from '@/assets/yoga-mat.jpg';
import playstation5Image from '@/assets/playstation-5.jpg';
import gamingKeyboardImage from '@/assets/gaming-keyboard.jpg';
import resistanceBandsImage from '@/assets/resistance-bands.jpg';
import cleanCodeBookImage from '@/assets/clean-code-book.jpg';
import iphone15ProImage from '@/assets/iphone-15-pro.jpg';

export interface User {
  id: string;
  name: string;
  age: number;
  preferences: string[];
  ratings: Record<string, number>;
  avatar?: string;
  location?: string;
  joinedDate?: string;
}

export interface Product {
  id: string;
  title: string;
  category: string;
  description: string;
  features: string[];
  averageRating: number;
  totalRatings: number;
  price: number;
  imageUrl: string;
  brand?: string;
  inStock?: boolean;
  shipping?: string;
  tags?: string[];
}

export interface Rating {
  userId: string;
  productId: string;
  rating: number;
  timestamp: Date;
}

export const sampleUsers: User[] = [
  {
    id: "u1",
    name: "Alice Johnson",
    age: 28,
    preferences: ["technology", "books", "fitness"],
    avatar: "https://images.unsplash.com/photo-1494790108755-2616b86e30d4?w=150&h=150&fit=crop&crop=face",
    location: "San Francisco, CA",
    joinedDate: "2023-06-15",
    ratings: {
      "p1": 5,
      "p2": 4,
      "p3": 3,
      "p7": 5,
      "p8": 4,
    }
  },
  {
    id: "u2", 
    name: "Bob Smith",
    age: 35,
    preferences: ["technology", "gaming", "music"],
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
    location: "New York, NY",
    joinedDate: "2023-03-22",
    ratings: {
      "p1": 4,
      "p4": 5,
      "p5": 3,
    }
  },
  {
    id: "u3",
    name: "Carol Davis",
    age: 42,
    preferences: ["books", "fitness", "cooking"],
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face",
    location: "Austin, TX",
    joinedDate: "2023-01-10",
    ratings: {
      "p2": 5,
      "p3": 4,
      "p6": 5,
    }
  },
  {
    id: "u4",
    name: "David Wilson",
    age: 31,
    preferences: ["gaming", "technology", "movies"],
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
    location: "Seattle, WA",
    joinedDate: "2023-08-05",
    ratings: {
      "p4": 4,
      "p5": 5,
      "p1": 3,
    }
  },
  {
    id: "u5",
    name: "Eva Brown",
    age: 26,
    preferences: ["fitness", "books", "travel"],
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&h=150&fit=crop&crop=face",
    location: "Denver, CO",
    joinedDate: "2023-11-12",
    ratings: {
      "p3": 5,
      "p6": 4,
      "p7": 3,
    }
  }
];

export const sampleProducts: Product[] = [
  {
    id: "p1",
    title: "MacBook Pro 16\"",
    category: "technology",
    description: "High-performance laptop with M2 Pro chip, perfect for developers and creators with exceptional performance and stunning display",
    features: ["M2 Pro chip", "16GB RAM", "512GB SSD", "Retina display"],
    averageRating: 4.5,
    totalRatings: 127,
    price: 2499,
    imageUrl: macbookProImage,
    brand: "Apple",
    inStock: true,
    shipping: "Free shipping",
    tags: ["laptop", "pro", "development", "creative"]
  },
  {
    id: "p2",
    title: "The Psychology of Computer Programming",
    category: "books",
    description: "Classic book on software development psychology and team dynamics by Gerald M. Weinberg",
    features: ["Software engineering", "Psychology", "Team management"],
    averageRating: 4.7,
    totalRatings: 89,
    price: 39,
    imageUrl: psychologyBookImage,
    brand: "Dorset House",
    inStock: true,
    shipping: "Free shipping",
    tags: ["programming", "psychology", "software", "classic"]
  },
  {
    id: "p3",
    title: "Yoga Mat Premium",
    category: "fitness",
    description: "Non-slip yoga mat made from eco-friendly materials with superior grip and comfort",
    features: ["Eco-friendly", "Non-slip", "6mm thick", "Lightweight"],
    averageRating: 4.3,
    totalRatings: 156,
    price: 79,
    imageUrl: yogaMatImage,
    brand: "EcoYoga",
    inStock: true,
    shipping: "Free shipping",
    tags: ["yoga", "fitness", "eco-friendly", "exercise"]
  },
  {
    id: "p4",
    title: "PlayStation 5",
    category: "gaming",
    description: "Next-generation gaming console with 4K graphics and ray tracing for immersive gaming experience",
    features: ["4K gaming", "Ray tracing", "SSD storage", "Haptic feedback"],
    averageRating: 4.8,
    totalRatings: 234,
    price: 499,
    imageUrl: playstation5Image,
    brand: "Sony",
    inStock: false,
    shipping: "Free shipping",
    tags: ["gaming", "console", "4K", "entertainment"]
  },
  {
    id: "p5",
    title: "Mechanical Gaming Keyboard",
    category: "gaming",
    description: "RGB backlit mechanical keyboard with Cherry MX switches for competitive gaming",
    features: ["Cherry MX switches", "RGB backlight", "Programmable keys"],
    averageRating: 4.4,
    totalRatings: 98,
    price: 149,
    imageUrl: gamingKeyboardImage,
    brand: "Corsair",
    inStock: true,
    shipping: "Free shipping",
    tags: ["keyboard", "gaming", "mechanical", "RGB"]
  },
  {
    id: "p6",
    title: "Resistance Bands Set",
    category: "fitness",
    description: "Complete set of resistance bands for home workouts with varying resistance levels",
    features: ["Multiple resistance levels", "Portable", "Exercise guide included"],
    averageRating: 4.2,
    totalRatings: 76,
    price: 29,
    imageUrl: resistanceBandsImage,
    brand: "FitnessPro",
    inStock: true,
    shipping: "Free shipping",
    tags: ["fitness", "resistance", "workout", "portable"]
  },
  {
    id: "p7",
    title: "Clean Code",
    category: "books",
    description: "A handbook of agile software craftsmanship by Robert C. Martin - essential for every developer",
    features: ["Software engineering", "Best practices", "Code quality"],
    averageRating: 4.6,
    totalRatings: 203,
    price: 45,
    imageUrl: cleanCodeBookImage,
    brand: "Prentice Hall",
    inStock: true,
    shipping: "Free shipping",
    tags: ["programming", "clean code", "software", "development"]
  },
  {
    id: "p8",
    title: "iPhone 15 Pro",
    category: "technology",
    description: "Latest iPhone with titanium design and A17 Pro chip for professional photography and performance",
    features: ["A17 Pro chip", "Titanium design", "Pro camera system"],
    averageRating: 4.5,
    totalRatings: 189,
    price: 999,
    imageUrl: iphone15ProImage,
    brand: "Apple",
    inStock: true,
    shipping: "Free shipping",
    tags: ["smartphone", "pro", "camera", "titanium"]
  }
];

export const sampleRatings: Rating[] = [
  { userId: "u1", productId: "p1", rating: 5, timestamp: new Date("2024-01-15") },
  { userId: "u1", productId: "p2", rating: 4, timestamp: new Date("2024-01-20") },
  { userId: "u2", productId: "p1", rating: 4, timestamp: new Date("2024-01-18") },
  { userId: "u2", productId: "p4", rating: 5, timestamp: new Date("2024-01-22") },
  { userId: "u3", productId: "p2", rating: 5, timestamp: new Date("2024-01-25") },
  { userId: "u3", productId: "p3", rating: 4, timestamp: new Date("2024-01-28") },
  // Add more sample ratings...
];

export const getRandomRating = () => Math.floor(Math.random() * 5) + 1;
export const getRandomUser = () => sampleUsers[Math.floor(Math.random() * sampleUsers.length)];
export const getRandomProduct = () => sampleProducts[Math.floor(Math.random() * sampleProducts.length)];