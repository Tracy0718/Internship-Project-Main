import { User, Product, sampleUsers, sampleProducts } from "@/data/sampleData";

// Cosine similarity calculation
export function cosineSimilarity(userA: User, userB: User): number {
  const ratingsA = userA.ratings;
  const ratingsB = userB.ratings;
  
  const commonItems = Object.keys(ratingsA).filter(item => item in ratingsB);
  
  if (commonItems.length === 0) return 0;
  
  const dotProduct = commonItems.reduce((sum, item) => 
    sum + ratingsA[item] * ratingsB[item], 0);
  
  const magnitudeA = Math.sqrt(commonItems.reduce((sum, item) => 
    sum + ratingsA[item] ** 2, 0));
  
  const magnitudeB = Math.sqrt(commonItems.reduce((sum, item) => 
    sum + ratingsB[item] ** 2, 0));
  
  if (magnitudeA === 0 || magnitudeB === 0) return 0;
  
  return dotProduct / (magnitudeA * magnitudeB);
}

// TF-IDF similarity for content-based filtering
export function calculateTFIDFSimilarity(productA: Product, productB: Product): number {
  const featuresA = new Set(productA.features.concat(productA.category.split(' ')));
  const featuresB = new Set(productB.features.concat(productB.category.split(' ')));
  
  const intersection = new Set([...featuresA].filter(x => featuresB.has(x)));
  const union = new Set([...featuresA, ...featuresB]);
  
  return intersection.size / union.size; // Jaccard similarity as simplified TF-IDF
}

// User-based collaborative filtering
export function getUserBasedRecommendations(targetUser: User, topK: number = 5): Product[] {
  const userSimilarities = sampleUsers
    .filter(user => user.id !== targetUser.id)
    .map(user => ({
      user,
      similarity: cosineSimilarity(targetUser, user)
    }))
    .sort((a, b) => b.similarity - a.similarity)
    .slice(0, 3); // Top 3 similar users
  
  const recommendedProducts: Record<string, { score: number; product: Product }> = {};
  
  userSimilarities.forEach(({ user, similarity }) => {
    Object.entries(user.ratings).forEach(([productId, rating]) => {
      if (!(productId in targetUser.ratings)) {
        const product = sampleProducts.find(p => p.id === productId);
        if (product) {
          if (!(productId in recommendedProducts)) {
            recommendedProducts[productId] = { score: 0, product };
          }
          recommendedProducts[productId].score += similarity * rating;
        }
      }
    });
  });
  
  return Object.values(recommendedProducts)
    .sort((a, b) => b.score - a.score)
    .slice(0, topK)
    .map(item => item.product);
}

// Item-based collaborative filtering
export function getItemBasedRecommendations(targetUser: User, topK: number = 5): Product[] {
  const userRatedProducts = Object.keys(targetUser.ratings)
    .map(productId => sampleProducts.find(p => p.id === productId))
    .filter(Boolean) as Product[];
  
  const recommendations: Record<string, { score: number; product: Product }> = {};
  
  userRatedProducts.forEach(ratedProduct => {
    const userRating = targetUser.ratings[ratedProduct.id];
    
    sampleProducts.forEach(product => {
      if (!(product.id in targetUser.ratings)) {
        // Calculate item similarity based on user ratings patterns
        let similarity = 0;
        let commonUsers = 0;
        
        sampleUsers.forEach(user => {
          if (user.ratings[ratedProduct.id] && user.ratings[product.id]) {
            similarity += Math.abs(user.ratings[ratedProduct.id] - user.ratings[product.id]);
            commonUsers++;
          }
        });
        
        if (commonUsers > 0) {
          similarity = 1 / (1 + similarity / commonUsers); // Inverse of average difference
          
          if (!(product.id in recommendations)) {
            recommendations[product.id] = { score: 0, product };
          }
          recommendations[product.id].score += similarity * userRating;
        }
      }
    });
  });
  
  return Object.values(recommendations)
    .sort((a, b) => b.score - a.score)
    .slice(0, topK)
    .map(item => item.product);
}

// Content-based filtering
export function getContentBasedRecommendations(targetUser: User, topK: number = 5): Product[] {
  const userRatedProducts = Object.keys(targetUser.ratings)
    .map(productId => sampleProducts.find(p => p.id === productId))
    .filter(Boolean) as Product[];
  
  const recommendations: Record<string, { score: number; product: Product }> = {};
  
  sampleProducts.forEach(product => {
    if (!(product.id in targetUser.ratings)) {
      let totalSimilarity = 0;
      let weightedRating = 0;
      
      userRatedProducts.forEach(ratedProduct => {
        const similarity = calculateTFIDFSimilarity(product, ratedProduct);
        const userRating = targetUser.ratings[ratedProduct.id];
        
        totalSimilarity += similarity;
        weightedRating += similarity * userRating;
      });
      
      if (totalSimilarity > 0) {
        const score = weightedRating / totalSimilarity;
        recommendations[product.id] = { score, product };
      }
    }
  });
  
  return Object.values(recommendations)
    .sort((a, b) => b.score - a.score)
    .slice(0, topK)
    .map(item => item.product);
}

// Hybrid recommendation system
export function getHybridRecommendations(
  targetUser: User, 
  weights: { collaborative: number; itemBased: number; contentBased: number } = 
    { collaborative: 0.4, itemBased: 0.3, contentBased: 0.3 },
  topK: number = 10
): { product: Product; score: number; sources: string[] }[] {
  
  const userBasedRecs = getUserBasedRecommendations(targetUser, topK);
  const itemBasedRecs = getItemBasedRecommendations(targetUser, topK);
  const contentBasedRecs = getContentBasedRecommendations(targetUser, topK);
  
  const hybridScores: Record<string, { 
    product: Product; 
    score: number; 
    sources: string[] 
  }> = {};
  
  // Combine scores from all methods
  const addToHybrid = (products: Product[], source: string, weight: number) => {
    products.forEach((product, index) => {
      const score = ((products.length - index) / products.length) * weight;
      
      if (!(product.id in hybridScores)) {
        hybridScores[product.id] = { 
          product, 
          score: 0, 
          sources: [] 
        };
      }
      
      hybridScores[product.id].score += score;
      if (!hybridScores[product.id].sources.includes(source)) {
        hybridScores[product.id].sources.push(source);
      }
    });
  };
  
  addToHybrid(userBasedRecs, 'User-Based CF', weights.collaborative);
  addToHybrid(itemBasedRecs, 'Item-Based CF', weights.itemBased);
  addToHybrid(contentBasedRecs, 'Content-Based', weights.contentBased);
  
  return Object.values(hybridScores)
    .sort((a, b) => b.score - a.score)
    .slice(0, topK);
}

// Evaluation metrics
export function calculatePrecisionAtK(predicted: Product[], actual: Product[], k: number): number {
  const predictedK = predicted.slice(0, k);
  const actualIds = new Set(actual.map(p => p.id));
  const relevantRetrieved = predictedK.filter(p => actualIds.has(p.id)).length;
  
  return relevantRetrieved / Math.min(k, predictedK.length);
}

export function calculateRecallAtK(predicted: Product[], actual: Product[], k: number): number {
  const predictedK = predicted.slice(0, k);
  const actualIds = new Set(actual.map(p => p.id));
  const relevantRetrieved = predictedK.filter(p => actualIds.has(p.id)).length;
  
  return actual.length > 0 ? relevantRetrieved / actual.length : 0;
}

export function calculateNDCG(predicted: Product[], actual: Product[], k: number): number {
  const predictedK = predicted.slice(0, k);
  const actualIds = new Set(actual.map(p => p.id));
  
  let dcg = 0;
  let idcg = 0;
  
  // Calculate DCG
  predictedK.forEach((product, index) => {
    const relevance = actualIds.has(product.id) ? 1 : 0;
    dcg += relevance / Math.log2(index + 2);
  });
  
  // Calculate IDCG (ideal DCG)
  for (let i = 0; i < Math.min(k, actual.length); i++) {
    idcg += 1 / Math.log2(i + 2);
  }
  
  return idcg > 0 ? dcg / idcg : 0;
}