import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Product } from "@/data/sampleData";
import { BarChart, Cpu, UserIcon, Brain, TrendingUp } from "lucide-react";

interface AlgorithmComparisonProps {
  recommendations: {
    hybrid: { product: Product; score: number; sources: string[] }[];
    userBased: Product[];
    itemBased: Product[];
    contentBased: Product[];
  };
}

export function AlgorithmComparison({ recommendations }: AlgorithmComparisonProps) {
  // Calculate overlap between algorithms
  const getOverlap = (list1: Product[], list2: Product[]) => {
    const ids1 = new Set(list1.map(p => p.id));
    const ids2 = new Set(list2.map(p => p.id));
    const intersection = new Set([...ids1].filter(x => ids2.has(x)));
    return intersection.size;
  };

  const userBasedIds = new Set(recommendations.userBased.map(p => p.id));
  const itemBasedIds = new Set(recommendations.itemBased.map(p => p.id));
  const contentBasedIds = new Set(recommendations.contentBased.map(p => p.id));

  const overlaps = {
    userItem: getOverlap(recommendations.userBased, recommendations.itemBased),
    userContent: getOverlap(recommendations.userBased, recommendations.contentBased),
    itemContent: getOverlap(recommendations.itemBased, recommendations.contentBased),
  };

  // Calculate diversity metrics
  const getUniqueCategories = (products: Product[]) => {
    return new Set(products.map(p => p.category)).size;
  };

  const getAverageRating = (products: Product[]) => {
    return products.reduce((sum, p) => sum + p.averageRating, 0) / products.length;
  };

  const algorithms = [
    {
      name: "User-Based CF",
      icon: UserIcon,
      color: "collaborative",
      products: recommendations.userBased,
      description: "Finds users with similar preferences",
      pros: ["High accuracy for active users", "Serendipitous discoveries"],
      cons: ["Cold start problem", "Scalability issues"]
    },
    {
      name: "Item-Based CF", 
      icon: Cpu,
      color: "contentBased",
      products: recommendations.itemBased,
      description: "Recommends items similar to rated ones",
      pros: ["Stable over time", "Explainable results"],
      cons: ["Limited novelty", "Popularity bias"]
    },
    {
      name: "Content-Based",
      icon: Brain,
      color: "hybrid", 
      products: recommendations.contentBased,
      description: "Matches user preferences to item features",
      pros: ["No cold start", "Transparent logic"],
      cons: ["Feature engineering required", "Limited diversity"]
    }
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BarChart className="h-5 w-5" />
          Algorithm Analysis
        </CardTitle>
        <CardDescription>
          Comparison of different recommendation approaches and their characteristics
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Algorithm Cards */}
        <div className="space-y-4">
          {algorithms.map((algorithm) => {
            const Icon = algorithm.icon;
            const categoryCount = getUniqueCategories(algorithm.products);
            const avgRating = getAverageRating(algorithm.products);
            
            return (
              <div key={algorithm.name} className="border border-border rounded-lg p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Icon className="h-4 w-4" />
                    <span className="font-medium">{algorithm.name}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <span>{algorithm.products.length} items</span>
                    <span>•</span>
                    <span>{categoryCount} categories</span>
                    <span>•</span>
                    <span>{avgRating.toFixed(1)} ★</span>
                  </div>
                </div>
                
                <p className="text-sm text-muted-foreground">
                  {algorithm.description}
                </p>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h5 className="text-xs font-medium text-green-400 mb-1">Pros</h5>
                    <ul className="text-xs text-muted-foreground space-y-1">
                      {algorithm.pros.map((pro, index) => (
                        <li key={index}>• {pro}</li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h5 className="text-xs font-medium text-red-400 mb-1">Cons</h5>
                    <ul className="text-xs text-muted-foreground space-y-1">
                      {algorithm.cons.map((con, index) => (
                        <li key={index}>• {con}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Overlap Analysis */}
        <div className="space-y-3">
          <h4 className="text-sm font-medium">Algorithm Overlap Analysis</h4>
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm">User-Based ∩ Item-Based</span>
              <Badge variant="outline">
                {overlaps.userItem} items ({((overlaps.userItem / Math.max(recommendations.userBased.length, 1)) * 100).toFixed(0)}%)
              </Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">User-Based ∩ Content-Based</span>
              <Badge variant="outline">
                {overlaps.userContent} items ({((overlaps.userContent / Math.max(recommendations.userBased.length, 1)) * 100).toFixed(0)}%)
              </Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Item-Based ∩ Content-Based</span>
              <Badge variant="outline">
                {overlaps.itemContent} items ({((overlaps.itemContent / Math.max(recommendations.itemBased.length, 1)) * 100).toFixed(0)}%)
              </Badge>
            </div>
          </div>
        </div>

        {/* Hybrid Benefits */}
        <div className="space-y-3 pt-4 border-t border-border">
          <div className="flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-primary" />
            <h4 className="text-sm font-medium">Hybrid System Benefits</h4>
          </div>
          <div className="text-sm text-muted-foreground space-y-1">
            <p>• Combines strengths of all three approaches</p>
            <p>• Reduces individual algorithm weaknesses</p>
            <p>• Provides more diverse and accurate recommendations</p>
            <p>• Adaptable weights for different use cases</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}