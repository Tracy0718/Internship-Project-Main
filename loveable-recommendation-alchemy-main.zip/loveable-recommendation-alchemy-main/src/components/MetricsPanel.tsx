import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { User, Product } from "@/data/sampleData";
import { BarChart3, TrendingUp, Target, Trophy } from "lucide-react";

interface MetricsPanelProps {
  recommendations: {
    hybrid: { product: Product; score: number; sources: string[] }[];
    userBased: Product[];
    itemBased: Product[];
    contentBased: Product[];
  };
  user: User;
}

export function MetricsPanel({ recommendations, user }: MetricsPanelProps) {
  // Mock evaluation metrics (in a real system, these would be calculated from historical data)
  const metrics = {
    precision_at_5: 0.82,
    recall_at_5: 0.76,
    ndcg_at_5: 0.89,
    coverage: 0.67,
    diversity: 0.73,
    novelty: 0.81
  };

  const getScoreColor = (score: number) => {
    if (score >= 0.8) return "text-green-400";
    if (score >= 0.6) return "text-yellow-400";
    return "text-red-400";
  };

  const getProgressColor = (score: number) => {
    if (score >= 0.8) return "bg-green-400";
    if (score >= 0.6) return "bg-yellow-400";
    return "bg-red-400";
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BarChart3 className="h-5 w-5" />
          Evaluation Metrics
        </CardTitle>
        <CardDescription>
          Performance metrics for the recommendation algorithms
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Primary Metrics */}
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Precision@5</span>
              <span className={`text-sm font-bold ${getScoreColor(metrics.precision_at_5)}`}>
                {(metrics.precision_at_5 * 100).toFixed(1)}%
              </span>
            </div>
            <Progress 
              value={metrics.precision_at_5 * 100} 
              className="h-2"
            />
            <p className="text-xs text-muted-foreground">
              Accuracy of top 5 recommendations
            </p>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Recall@5</span>
              <span className={`text-sm font-bold ${getScoreColor(metrics.recall_at_5)}`}>
                {(metrics.recall_at_5 * 100).toFixed(1)}%
              </span>
            </div>
            <Progress 
              value={metrics.recall_at_5 * 100} 
              className="h-2"
            />
            <p className="text-xs text-muted-foreground">
              Coverage of relevant items
            </p>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">NDCG@5</span>
              <span className={`text-sm font-bold ${getScoreColor(metrics.ndcg_at_5)}`}>
                {(metrics.ndcg_at_5 * 100).toFixed(1)}%
              </span>
            </div>
            <Progress 
              value={metrics.ndcg_at_5 * 100} 
              className="h-2"
            />
            <p className="text-xs text-muted-foreground">
              Ranking quality measure
            </p>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">Diversity</span>
              <span className={`text-sm font-bold ${getScoreColor(metrics.diversity)}`}>
                {(metrics.diversity * 100).toFixed(1)}%
              </span>
            </div>
            <Progress 
              value={metrics.diversity * 100} 
              className="h-2"
            />
            <p className="text-xs text-muted-foreground">
              Variety in recommendations
            </p>
          </div>
        </div>

        {/* Algorithm Performance Comparison */}
        <div className="space-y-3">
          <h4 className="text-sm font-medium">Algorithm Performance</h4>
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm">Hybrid System</span>
              <div className="flex items-center gap-2">
                <Progress value={89} className="w-20 h-2" />
                <span className="text-sm font-medium text-green-400">89%</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">User-Based CF</span>
              <div className="flex items-center gap-2">
                <Progress value={76} className="w-20 h-2" />
                <span className="text-sm font-medium text-yellow-400">76%</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Item-Based CF</span>
              <div className="flex items-center gap-2">
                <Progress value={71} className="w-20 h-2" />
                <span className="text-sm font-medium text-yellow-400">71%</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Content-Based</span>
              <div className="flex items-center gap-2">
                <Progress value={68} className="w-20 h-2" />
                <span className="text-sm font-medium text-yellow-400">68%</span>
              </div>
            </div>
          </div>
        </div>

        {/* User Stats */}
        <div className="space-y-3 pt-4 border-t border-border">
          <h4 className="text-sm font-medium">User Profile Stats</h4>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-muted-foreground">Rated Items:</span>
              <span className="ml-2 font-medium">{Object.keys(user.ratings).length}</span>
            </div>
            <div>
              <span className="text-muted-foreground">Avg Rating:</span>
              <span className="ml-2 font-medium">
                {(Object.values(user.ratings).reduce((a, b) => a + b, 0) / Object.values(user.ratings).length).toFixed(1)}
              </span>
            </div>
            <div>
              <span className="text-muted-foreground">Preferences:</span>
              <span className="ml-2 font-medium">{user.preferences.length}</span>
            </div>
            <div>
              <span className="text-muted-foreground">Coverage:</span>
              <span className="ml-2 font-medium">{(metrics.coverage * 100).toFixed(0)}%</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}