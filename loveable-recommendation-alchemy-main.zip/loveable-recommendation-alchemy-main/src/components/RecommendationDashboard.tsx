import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { User, Product, sampleUsers } from "@/data/sampleData";
import { 
  getHybridRecommendations, 
  getUserBasedRecommendations,
  getItemBasedRecommendations,
  getContentBasedRecommendations,
  calculatePrecisionAtK,
  calculateRecallAtK,
  calculateNDCG
} from "@/lib/recommendationEngine";
import { UserIcon, Cpu, Brain, BarChart3, TrendingUp, LogOut, Settings, ShoppingCart } from "lucide-react";
import { ProductCard } from "./ProductCard";
import { MetricsPanel } from "./MetricsPanel";
import { AlgorithmComparison } from "./AlgorithmComparison";
import { useCart } from "../hooks/useCart";

interface RecommendationDashboardProps {
  user: User | null;
  onSignOut: () => void;
}

export function RecommendationDashboard({ user, onSignOut }: RecommendationDashboardProps) {
  const [selectedUser, setSelectedUser] = useState<User>(user || sampleUsers[0]);
  const { cartItems, addToCart, getCartCount, getCartTotal } = useCart();
  const [recommendations, setRecommendations] = useState<{
    hybrid: { product: Product; score: number; sources: string[] }[];
    userBased: Product[];
    itemBased: Product[];
    contentBased: Product[];
  }>({
    hybrid: [],
    userBased: [],
    itemBased: [],
    contentBased: []
  });
  
  const [isLoading, setIsLoading] = useState(false);
  const [weights, setWeights] = useState({
    collaborative: 40,
    itemBased: 30,
    contentBased: 30
  });

  const generateRecommendations = async () => {
    setIsLoading(true);
    
    // Simulate API delay for realistic UX
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const normalizedWeights = {
      collaborative: weights.collaborative / 100,
      itemBased: weights.itemBased / 100,
      contentBased: weights.contentBased / 100
    };
    
    const hybridRecs = getHybridRecommendations(selectedUser, normalizedWeights, 8);
    const userBasedRecs = getUserBasedRecommendations(selectedUser, 8);
    const itemBasedRecs = getItemBasedRecommendations(selectedUser, 8);
    const contentBasedRecs = getContentBasedRecommendations(selectedUser, 8);
    
    setRecommendations({
      hybrid: hybridRecs,
      userBased: userBasedRecs,
      itemBased: itemBasedRecs,
      contentBased: contentBasedRecs
    });
    
    setIsLoading(false);
  };

  useEffect(() => {
    generateRecommendations();
  }, [selectedUser]);

  const userRatedCount = Object.keys(selectedUser.ratings).length;
  const totalWeight = weights.collaborative + weights.itemBased + weights.contentBased;

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header with User Profile */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <img 
              src={selectedUser.avatar || "/api/placeholder/60/60"} 
              alt={selectedUser.name}
              className="w-12 h-12 rounded-full border-2 border-primary/20"
            />
            <div>
              <h2 className="text-xl font-semibold">{selectedUser.name}</h2>
              <p className="text-sm text-muted-foreground">{selectedUser.location}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="relative">
              <Button variant="outline" size="sm">
                <ShoppingCart className="h-4 w-4 mr-2" />
                Cart ({getCartCount()})
              </Button>
              {getCartCount() > 0 && (
                <Badge className="absolute -top-2 -right-2 h-5 w-5 p-0 text-xs flex items-center justify-center">
                  {getCartCount()}
                </Badge>
              )}
            </div>
            <Button variant="outline" size="sm">
              <Settings className="h-4 w-4 mr-2" />
              Settings
            </Button>
            <Button variant="outline" size="sm" onClick={onSignOut}>
              <LogOut className="h-4 w-4 mr-2" />
              Sign Out
            </Button>
          </div>
        </div>

        {/* Main Title */}
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-collaborative bg-clip-text text-transparent">
            Hybrid Recommendation System
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Advanced machine learning system combining collaborative filtering, content-based filtering, 
            and hybrid approaches for personalized product recommendations
          </p>
        </div>

        {/* User Selection & Weights */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <UserIcon className="h-5 w-5" />
                Select User
              </CardTitle>
              <CardDescription>
                Choose a user to generate personalized recommendations
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Select 
                value={selectedUser.id} 
                onValueChange={(userId) => {
                  const user = sampleUsers.find(u => u.id === userId);
                  if (user) setSelectedUser(user);
                }}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {sampleUsers.map(user => (
                    <SelectItem key={user.id} value={user.id}>
                      {user.name} ({user.age}y, {Object.keys(user.ratings).length} ratings)
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Rated Products:</span>
                  <span className="font-medium">{userRatedCount}</span>
                </div>
                <div className="flex flex-wrap gap-1">
                  {selectedUser.preferences.map(pref => (
                    <Badge key={pref} variant="secondary" className="text-xs">
                      {pref}
                    </Badge>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Algorithm Weights
              </CardTitle>
              <CardDescription>
                Adjust the influence of each recommendation algorithm
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>User-Based CF</span>
                    <span className="font-medium">{weights.collaborative}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={weights.collaborative}
                    onChange={(e) => setWeights(prev => ({ ...prev, collaborative: parseInt(e.target.value) }))}
                    className="w-full h-2 bg-secondary rounded-lg appearance-none cursor-pointer"
                    style={{
                      background: `linear-gradient(to right, hsl(var(--collaborative)) 0%, hsl(var(--collaborative)) ${weights.collaborative}%, hsl(var(--secondary)) ${weights.collaborative}%, hsl(var(--secondary)) 100%)`
                    }}
                  />
                </div>
                
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Item-Based CF</span>
                    <span className="font-medium">{weights.itemBased}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={weights.itemBased}
                    onChange={(e) => setWeights(prev => ({ ...prev, itemBased: parseInt(e.target.value) }))}
                    className="w-full h-2 bg-secondary rounded-lg appearance-none cursor-pointer"
                    style={{
                      background: `linear-gradient(to right, hsl(var(--content-based)) 0%, hsl(var(--content-based)) ${weights.itemBased}%, hsl(var(--secondary)) ${weights.itemBased}%, hsl(var(--secondary)) 100%)`
                    }}
                  />
                </div>
                
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Content-Based</span>
                    <span className="font-medium">{weights.contentBased}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={weights.contentBased}
                    onChange={(e) => setWeights(prev => ({ ...prev, contentBased: parseInt(e.target.value) }))}
                    className="w-full h-2 bg-secondary rounded-lg appearance-none cursor-pointer"
                    style={{
                      background: `linear-gradient(to right, hsl(var(--hybrid)) 0%, hsl(var(--hybrid)) ${weights.contentBased}%, hsl(var(--secondary)) ${weights.contentBased}%, hsl(var(--secondary)) 100%)`
                    }}
                  />
                </div>
              </div>
              
              <div className="pt-2">
                <Button 
                  onClick={generateRecommendations} 
                  disabled={isLoading || totalWeight === 0}
                  className="w-full"
                >
                  {isLoading ? "Generating..." : "Update Recommendations"}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recommendations Tabs */}
        <Tabs defaultValue="hybrid" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="hybrid" className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Hybrid
            </TabsTrigger>
            <TabsTrigger value="user-based" className="flex items-center gap-2">
              <UserIcon className="h-4 w-4" />
              User-Based
            </TabsTrigger>
            <TabsTrigger value="item-based" className="flex items-center gap-2">
              <Cpu className="h-4 w-4" />
              Item-Based
            </TabsTrigger>
            <TabsTrigger value="content-based" className="flex items-center gap-2">
              <Brain className="h-4 w-4" />
              Content-Based
            </TabsTrigger>
          </TabsList>

          <TabsContent value="hybrid" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Hybrid Recommendations</CardTitle>
                <CardDescription>
                  Combined results from all recommendation algorithms weighted by your preferences
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    {Array.from({ length: 8 }).map((_, i) => (
                      <div key={i} className="animate-pulse">
                        <div className="bg-muted rounded-lg h-48"></div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    {recommendations.hybrid.map((rec, index) => (
                      <ProductCard 
                        key={rec.product.id} 
                        product={rec.product}
                        rank={index + 1}
                        score={rec.score}
                        sources={rec.sources}
                        onAddToCart={addToCart}
                      />
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="user-based">
            <Card>
              <CardHeader>
                <CardTitle>User-Based Collaborative Filtering</CardTitle>
                <CardDescription>
                  Recommendations based on users with similar rating patterns
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  {recommendations.userBased.map((product, index) => (
                    <ProductCard 
                      key={product.id} 
                      product={product}
                      rank={index + 1}
                      sources={['User-Based CF']}
                      onAddToCart={addToCart}
                    />
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="item-based">
            <Card>
              <CardHeader>
                <CardTitle>Item-Based Collaborative Filtering</CardTitle>
                <CardDescription>
                  Recommendations based on items similar to those you've rated highly
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  {recommendations.itemBased.map((product, index) => (
                    <ProductCard 
                      key={product.id} 
                      product={product}
                      rank={index + 1}
                      sources={['Item-Based CF']}
                      onAddToCart={addToCart}
                    />
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="content-based">
            <Card>
              <CardHeader>
                <CardTitle>Content-Based Filtering</CardTitle>
                <CardDescription>
                  Recommendations based on product features and your preferences
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  {recommendations.contentBased.map((product, index) => (
                    <ProductCard 
                      key={product.id} 
                      product={product}
                      rank={index + 1}
                      sources={['Content-Based']}
                      onAddToCart={addToCart}
                    />
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Analytics & Metrics */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <MetricsPanel recommendations={recommendations} user={selectedUser} />
          <AlgorithmComparison recommendations={recommendations} />
        </div>
      </div>
    </div>
  );
}