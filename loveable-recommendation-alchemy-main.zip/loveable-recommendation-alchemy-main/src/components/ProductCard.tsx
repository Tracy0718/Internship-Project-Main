import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Product } from "@/data/sampleData";
import { Star, Award, ShoppingCart, Heart, Package, Truck, CheckCircle, XCircle } from "lucide-react";

interface ProductCardProps {
  product: Product;
  rank?: number;
  score?: number;
  sources?: string[];
  onAddToCart?: (product: Product) => void;
}

export function ProductCard({ product, rank, score, sources, onAddToCart }: ProductCardProps) {
  const getSourceColor = (source: string) => {
    switch (source) {
      case 'User-Based CF':
        return 'bg-collaborative text-collaborative-foreground';
      case 'Item-Based CF':
        return 'bg-contentBased text-contentBased-foreground';
      case 'Content-Based':
        return 'bg-hybrid text-hybrid-foreground';
      default:
        return 'bg-secondary text-secondary-foreground';
    }
  };

  return (
    <Card className="group h-full transition-all duration-300 hover:shadow-2xl hover:shadow-primary/10 hover:scale-[1.02] border-border/50 bg-card/50 backdrop-blur-sm overflow-hidden">
      <CardContent className="p-0">
        {/* Header with Rank and Actions */}
        <div className="relative">
          {/* Product Image */}
          <div className="relative w-full h-48 overflow-hidden">
            <img 
              src={product.imageUrl} 
              alt={product.title}
              className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
            
            {/* Rank Badge */}
            {rank && (
              <div className="absolute top-3 left-3 z-10">
                <Badge variant="outline" className="flex items-center gap-1 bg-background/90 backdrop-blur-sm">
                  <Award className="h-3 w-3" />
                  #{rank}
                </Badge>
              </div>
            )}
            
            {/* Actions */}
            <div className="absolute top-3 right-3 z-10 flex gap-2">
              <Button size="sm" variant="outline" className="p-2 h-8 w-8 bg-background/90 backdrop-blur-sm">
                <Heart className="h-3 w-3" />
              </Button>
            </div>
            
            {/* Stock Status */}
            <div className="absolute bottom-3 right-3 z-10">
              <Badge variant={product.inStock ? "default" : "destructive"} className="flex items-center gap-1">
                {product.inStock ? <CheckCircle className="h-3 w-3" /> : <XCircle className="h-3 w-3" />}
                {product.inStock ? "In Stock" : "Out of Stock"}
              </Badge>
            </div>
          </div>
        </div>

        {/* Product Info */}
        <div className="p-4 space-y-3">
          {/* Brand and Category */}
          <div className="flex items-center justify-between">
            <Badge variant="secondary" className="text-xs">
              {product.brand}
            </Badge>
            <span className="text-xs text-muted-foreground capitalize">{product.category}</span>
          </div>

          {/* Title */}
          <h3 className="font-semibold text-sm line-clamp-2 group-hover:text-primary transition-colors">
            {product.title}
          </h3>
          
          {/* Description */}
          <p className="text-xs text-muted-foreground line-clamp-2">
            {product.description}
          </p>
          
          {/* Rating and Reviews */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1">
                <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                <span className="text-xs font-medium">{product.averageRating}</span>
              </div>
              <span className="text-xs text-muted-foreground">
                ({product.totalRatings} reviews)
              </span>
            </div>
            {score && (
              <span className="text-xs text-muted-foreground">
                Score: {score.toFixed(3)}
              </span>
            )}
          </div>

          {/* Price and Shipping */}
          <div className="flex items-center justify-between">
            <div className="text-lg font-bold text-primary">
              ${product.price}
            </div>
            {product.shipping && (
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <Truck className="h-3 w-3" />
                {product.shipping}
              </div>
            )}
          </div>

          {/* Features */}
          <div className="flex flex-wrap gap-1">
            {product.features.slice(0, 3).map((feature) => (
              <Badge key={feature} variant="outline" className="text-xs">
                {feature}
              </Badge>
            ))}
            {product.features.length > 3 && (
              <Badge variant="outline" className="text-xs">
                +{product.features.length - 3}
              </Badge>
            )}
          </div>

          {/* Tags */}
          {product.tags && product.tags.length > 0 && (
            <div className="flex flex-wrap gap-1">
              {product.tags.slice(0, 2).map((tag) => (
                <Badge key={tag} variant="secondary" className="text-xs">
                  #{tag}
                </Badge>
              ))}
            </div>
          )}

          {/* Sources */}
          {sources && sources.length > 0 && (
            <div className="flex flex-wrap gap-1">
              {sources.map((source) => (
                <Badge 
                  key={source} 
                  className={`text-xs ${getSourceColor(source)}`}
                >
                  {source}
                </Badge>
              ))}
            </div>
          )}

          {/* Action Button */}
          <Button 
            size="sm" 
            className="w-full mt-3 bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70"
            disabled={!product.inStock}
            onClick={() => product.inStock && onAddToCart?.(product)}
          >
            <ShoppingCart className="h-3 w-3 mr-2" />
            {product.inStock ? "Add to Cart" : "Out of Stock"}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}